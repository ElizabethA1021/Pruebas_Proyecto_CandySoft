from .rol_serializer import RolSerializer
from .permiso_serializer import PermisoSerializer
from .permiso_rol_serializer import PermisoRolSerializer

