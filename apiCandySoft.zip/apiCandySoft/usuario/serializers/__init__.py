from .usuario import UsuarioSerializer
from .manicurista import ManicuristaSerializer
from .cliente import ClienteSerializer
