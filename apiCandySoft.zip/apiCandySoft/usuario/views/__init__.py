from .cliente import ClienteViewSet
from .usuario import UsuarioViewSet
from .manicurista import ManicuristaViewSet